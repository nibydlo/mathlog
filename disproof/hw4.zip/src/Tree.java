import java.util.ArrayList;
import java.util.HashMap;

public class Tree {

    int childCount = 0;
    ArrayList<Tree> children = new ArrayList<>();

    Tree(String st) {

    }
}
